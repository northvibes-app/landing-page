---
name: Nordic Care Equity
colors:
  surface: '#f5fafa'
  surface-dim: '#d5dbdb'
  surface-bright: '#f5fafa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff5f4'
  surface-container: '#e9efee'
  surface-container-high: '#e4e9e9'
  surface-container-highest: '#dee4e3'
  on-surface: '#171d1d'
  on-surface-variant: '#554149'
  inverse-surface: '#2c3132'
  inverse-on-surface: '#ecf2f1'
  outline: '#887179'
  outline-variant: '#dbbfc8'
  surface-tint: '#a92a6f'
  primary: '#5b0037'
  on-primary: '#ffffff'
  primary-container: '#830051'
  on-primary-container: '#ff88be'
  inverse-primary: '#ffb0d0'
  secondary: '#376090'
  on-secondary: '#ffffff'
  secondary-container: '#a1c9ff'
  on-secondary-container: '#2a5483'
  tertiary: '#3c2800'
  on-tertiary: '#ffffff'
  tertiary-container: '#583d00'
  on-tertiary-container: '#e3a300'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd8e6'
  primary-fixed-dim: '#ffb0d0'
  on-primary-fixed: '#3d0023'
  on-primary-fixed-variant: '#8a0956'
  secondary-fixed: '#d2e4ff'
  secondary-fixed-dim: '#a1c9ff'
  on-secondary-fixed: '#001c37'
  on-secondary-fixed-variant: '#1b4876'
  tertiary-fixed: '#ffdea9'
  tertiary-fixed-dim: '#ffba28'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5e4100'
  background: '#f5fafa'
  on-background: '#171d1d'
  surface-variant: '#dee4e3'
typography:
  headline-xl:
    fontFamily: Source Serif 4
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 52px
  headline-xl-mobile:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 42px
  headline-lg-mobile:
    fontFamily: Source Serif 4
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
  headline-md:
    fontFamily: Source Serif 4
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Source Serif 4
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  gutter-lg: 2rem
  margin: 1.5rem
  margin-sm: 1rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a dignified, serene, and intensely reassuring digital environment for patients accessing municipal and regional healthcare across Finland. Rooted in the principles of Nordic social equality, universal accessibility, and AstraZeneca’s clinical authority, the visual language balances human warmth with institutional rigor.

The aesthetic fuses **Modern Clinical Minimalism** with **Nordic Functionalism**:
- **Clarity over ornament:** Uncluttered layouts with generous negative space to reduce cognitive fatigue during stressful medical interactions.
- **Empathetic precision:** Gentle micro-radii and comforting tonal warmth that dispel sterile hospital coldness without sacrificing clinical credibility.
- **Universal legibility:** Uncompromising WCAG AAA compliance built specifically to serve elderly, neurodivergent, and rural demographics across diverse geographic and linguistic regions of Finland.

## Colors

The palette leverages AstraZeneca's heritage Mulberry and Nordic institutional Navy as anchors, softened by clinical atmospheric tones and intentional data accents.

- **Primary (`#830051` Mulberry):** Applied deliberately to critical primary action paths, critical healthcare status flags, and authoritative portal landmarks. Used sparingly to avoid visual agitation.
- **Secondary (`#003865` Navy):** Provides architectural grounding, institutional confidence, and secondary navigation elements, achieving exceptional contrast against light backdrops.
- **Tertiary (`#EFAB00` Gold):** Functions strictly as an informative indicator for alerts, ongoing appointments, and urgent notices. It should never serve as body text on light backgrounds.
- **Neutral Palette:**
  - **Canvas Surface:** Pale Grey (`#EBEFEE`) establishes a calm, glare-free baseline that reduces eye strain compared to pure white.
  - **Foreground & Text:** Near-black (`#1B1B1B`) ensures effortless readability for long-form medical reports, supported by Graphite (`#3C4242`) for secondary labels and metadata.
  - **Tonal Structure:** Sage Grey (`#9DB0AC`) defines low-contrast boundaries, dividers, and disabled states.
- **Data & Metric Accents:** Cyan/Teal (`#1AADCE`) and Light Blue (`#68D2DF`) are reserved specifically for biometric trends, timeline progress, and medical visualization to signify health and stability.

## Typography

Typography prioritizes clarity, human dignity, and readability across Finnish and Swedish orthography.

- **Headlines (Source Serif 4):** Editorial serif letterforms bring an authoritative, reassuring, and human bedside manner to diagnosis summaries, section titles, and page headers.
- **Interface & Content (Inter):** System-grade grotesque sans-serif engineered for pixel-grid sharpness, high x-height, and open counters. Preserves legibility when rendering dense laboratory reports, prescription dosages, and Finnish compound words.
- **Rhythm & Line Height:** Line heights remain generous (minimum 1.5x for body copy) to support accessibility for patients with vision impairments or cognitive load limitations.

## Layout & Spacing

The layout model is anchored by an accessible, responsive grid configured to handle data density without feeling cluttered:

- **Desktop (1024px+):** 12-column responsive fluid grid constrained to a maximum reading container of 1280px. Columns use `2rem` gutters and `3rem` screen margins to ensure restful breathing room.
- **Tablet (640px – 1023px):** 8-column grid with `1.5rem` gutters and `1.5rem` margins. Side panels collapse into fluid contextual shelves.
- **Mobile (<640px):** 4-column fluid layout with `1rem` gutters and `1rem` margins. Interactive touch targets maintain a strict minimum hit dimension of 48px to accommodate users with motor tremors or tactile impairments.

## Elevation & Depth

To sustain a calm clinical disposition, the system avoids dramatic drop shadows, stark black drop-offs, and glossy skeumorphs. Depth is articulated via **Tonal Stratification** paired with **Ambient Luminescence**:

- **Layer 0 (Canvas):** Base background tinted in Pale Grey (`#EBEFEE`).
- **Layer 1 (Cards & Worksurfaces):** Pure white (`#FFFFFF`) containers resting directly on the canvas, bounded by a 1px soft stroke of Sage Grey at 40% opacity (`rgba(157, 176, 172, 0.40)`).
- **Layer 2 (Elevated & Active Panels):** Floating navigation headers and elevated diagnostic cards utilize an ambient shadow tinted with secondary navy (`#003865` at 5% opacity, 16px blur, 4px Y-offset) without harsh edge delineation.
- **Layer 3 (Modals & Overlays):** Modal backdrops introduce a serene frosted veil (`backdrop-filter: blur(8px)`) tinted with Navy at 20% opacity, maintaining spatial orientation while focusing attention on critical consent and prescription forms.

## Shapes

The interface embraces a gentle, human geometry. A balanced corner radius (Level 2) conveys safety and approachability while preserving the structured architectural order required for medical documentation:

- **Standard Containers & Cards:** `0.5rem` (8px) corner radius to create inviting, non-threatening groupings of patient records.
- **Interactive Controls (Buttons, Inputs, Selectors):** `0.5rem` (8px) to establish tactile affordance.
- **Pills & Status Indicators:** Fully rounded (`9999px`) badges reserved exclusively for categorical metadata, triage states, and health flags.

## Components

### Buttons
- **Primary:** Mulberry (`#830051`) background with crisp white typography. Height: 48px minimum. Hover state darkens slightly to `#680040` with no disruptive displacement. Focus state presents a 3px outer ring in Cyan (`#1AADCE`) with a 2px white gap.
- **Secondary:** Transparent fill with a 1.5px solid border in Navy (`#003865`) and Navy text.
- **Tertiary / Subtle:** Transparent background with Navy text, turning to Pale Grey fill on hover.

### Cards
- Pure white fill framed with an understated Sage Grey border. Card headers pair Source Serif 4 section titles with Inter metadata labels. Padding remains spacious (`1.5rem`) to compartmentalize patient records clearly.

### Input Fields & Controls
- Form controls feature a minimum height of 48px, pure white surface, and 1.5px Graphite/Sage Grey border. Focused fields transition to a Teal (`#1AADCE`) border with a complementary subtle glow. Helper labels sit persistently above inputs to assist cognitive recall.
- **Checkboxes & Radios:** Scaled to 24x24px with high-contrast Mulberry active fills, exceeding accessibility requirements for touch interaction.

### Chips & Health Badges
- Compact indicators combining a tinted pastel surface (e.g., Light Blue `#68D2DF` at 15% opacity) with high-contrast text (`#003865`) for physiological metrics, appointment status, and dosage schedules.

### Healthcare-Specific Components
- **Triage & Risk Banner:** A patient alert banner utilizing Gold (`#EFAB00`) background tinting with Near-black text and secondary Mulberry action links for immediate regional dispatch and advisory triage.
- **Dosage & Biometric Timeline:** Data-dense, calming trackers rendered with Teal and Cyan vectors across Sage Grey track lines, presenting biometric stability and treatment adherence clearly.